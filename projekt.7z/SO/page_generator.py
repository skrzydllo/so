import random


def generate(nb_of_pages, str_len):
    a = [random.randint(1, nb_of_pages) for i in range(str_len)]
    return a
