import sjf
import fcfs
import utils


def generate():
    for i in range(utils.nb_of_samples):
        sjf.sjf(utils.p_sample + str(i + 1) + '.txt', utils.path_sjf_res)
        fcfs.fcfs(utils.p_sample + str(i + 1) + '.txt', utils.path_fcfs_res)


def display():
    f = open(utils.path_fcfs_res)
    fcfs_res = [[float(str(i)) for i in j.split(';')] for j in f.read().split('\n')[:-1]]
    f.close()
    total_wait_fcfs = [sum(x) for x in zip(*fcfs_res)]
    average_wait_fcfs = total_wait_fcfs[0] / len(fcfs_res)
    average_tat_fcfs = total_wait_fcfs[1] / len(fcfs_res)

    f = open(utils.path_sjf_res)
    sjf_res = [[float(str(i)) for i in j.split(';')] for j in f.read().split('\n')[:-1]]
    f.close()
    total_wait_sjf = [sum(x) for x in zip(*sjf_res)]
    average_wait_sjf = total_wait_sjf[0] / len(sjf_res)
    average_tat_sjf = total_wait_sjf[1] / len(sjf_res)

    print("Avg. waiting time for FCFS:   ", average_wait_fcfs)
    print("Avg. waiting time for SJF:    ", average_wait_sjf)
    print("Avg. Turn And. Time for FCFS: ", average_tat_fcfs)
    print("Avg. Turn And. Time for SJF:  ",  average_tat_sjf)


if __name__ == '__main__':
    generate()
    display()
