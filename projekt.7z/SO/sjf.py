from itertools import accumulate


def sjf(path_to_sample: str, path_to_results: bool, at_zero_flag=True, verbose=False):
    f = open(path_to_sample, 'r')
    f.readline()
    f.readline()

    inputs = [[int(i) for i in j.split(';')] for j in f.read().split('\n')[:-1]]

    comp_t = []  # contains seconds in which each process finished its task
    ta_t = []  # turn around time --> comp_t[i] - AT
    wait_t = []  # waiting time of each ps --> tn_t - BT

    if at_zero_flag:
        for i in range(len(inputs)):
            inputs[i][1] = 0

        # sorting by BT
        inputs = sorted(inputs, key=lambda x: (x[2], x[0]))
        comp_t = [i[2] for i in inputs]
        comp_t = list(accumulate(comp_t))

        wait_t = [comp_t[i] - inputs[i][2] for i in range(len(inputs))]

        # TNT is the same as Comp. Time since AT is 0
        ta_t = [comp_t[i] - inputs[i][1] for i in range(len(inputs))]

        mean_wait_t = round(sum(wait_t) / len(wait_t), 2)
        mean_tn_t = round(sum(ta_t) / len(ta_t), 2)

    # TODO: implementation code for at_zero_flag=False; include waiting ps to come
    '''
    if not at_zero_flag:
        # sorting by AT and next BT // here only by BT since AT is 0 for all
        inputs = sorted(inputs, key=lambda x: (x[1], x[2]))

        comp_t = [i[2] for i in inputs]
        comp_t = list(accumulate(comp_t))

        ta_t = [comp_t[i] - inputs[i][1] for i in range(len(inputs))]
        wait_t = [comp_t[i] - inputs[i][2] for i in range(len(inputs))]
    '''

    if verbose:
        print("\nProcesses: [#PS,AT,BT]:\t\t\t", inputs)
        print("Time of Completion of each PS:  ", comp_t)
        print('Waiting Time of each PS:\t\t', wait_t)
        # print('\naverage turn around time:\t\t', round(sum(ta_t) / len(ta_t), 2))
        print('Average Waiting Time:\t\t\t', mean_wait_t, ' sec.')
        print('Average Turn Around Time:\t\t', mean_tn_t, ' sec.')

    o = open(path_to_results, "a+")
    o.write(str(mean_wait_t) + ';' + str(mean_tn_t) + '\n')
    o.close()
    f.close()
