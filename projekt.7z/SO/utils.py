nb_of_samples = 100
nb_of_ps = 100
max_AT = 120  # in seconds
max_BT = 100  # in seconds

path_to_samples = './samples/'
sample_name = 'sample_'
path_to_results = './results/'
path_fcfs_res = path_to_results + 'fcfs_results.txt'
path_sjf_res = path_to_results + 'sjf_results.txt'

p_sample = path_to_samples + sample_name
