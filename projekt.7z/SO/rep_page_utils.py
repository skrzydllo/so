nb_of_frames = 3
str_len = 100
nb_of_pages = 20
