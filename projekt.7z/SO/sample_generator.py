import random
import utils

for j in range(utils.nb_of_samples):

    f = open(utils.p_sample + str(j + 1) + ".txt", "w+")
    f.write("process nb ; arrival time ; burst time\n\n")
    for i in range(utils.nb_of_ps):
        f.write(
            str(i + 1) + ";" + str(random.randint(0, utils.max_AT)) + ";" + str(random.randint(1, utils.max_BT)) + '\n')
    f.close()
