import rep_page_utils as r
import page_generator


def sim_lru(nb_of_frames, nb_of_pages, str_len, verbose=False):
    frame = []
    st = []
    faults = 0
    test_str = page_generator.generate(nb_of_pages, str_len)
    if verbose:
        print('\n\nTesting string: ', test_str, '\n')
        print('Str| Frame\n')
    for i in test_str:
        if i not in frame:
            if len(frame) < nb_of_frames:
                frame.append(i)
                st.append(len(frame) - 1)
            else:
                # st holds values from 0 to len(frame)
                pos = st.pop(0)
                frame[pos] = i
                st.append(pos)
            faults += 1
        else:
            t = frame.index(i)
            t = st.index(t)
            t = st.pop(t)
            st.append(t)
        if verbose:
            print('%2d |' % i, frame)

    return [test_str, faults]


if __name__ == '__main__':
    f = open('lru_results.txt', "w+")
    for i in [3, 5, 7]:
        results = sim_lru(i,r.nb_of_pages, r.str_len, verbose=True)
        f.write(
            'nb_of_frames: ' + str(i) + '\ntested_string: ' + str(results[0]) + '\nfaults: ' + str(results[1]) + '\n\n')
